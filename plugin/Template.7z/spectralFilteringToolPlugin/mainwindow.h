#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>
#include <QFileDialog>
#include <QMessageBox>
#include <time.h>

#include "qlabelbar.h"
#include "opencv2/opencv.hpp"
#include "imgcore.h"
#include "imageprocessing.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void setImageFromMain(cv::Mat &img){_from_Main_img = img.clone();}
signals:
    void sendSig();
private slots:
    void resizeEvent(QResizeEvent * e);
    void closeEvent(QCloseEvent *event);
private:
    Ui::MainWindow *ui;
    cv::Mat _from_Main_img;
    cv::Mat image;
};

#endif // MAINWINDOW_H
