#include "spectralFilteringToolPlugin.h"
#include <QDebug>
spectralFilteringToolPlugin::~spectralFilteringToolPlugin()
{

}

void spectralFilteringToolPlugin::receiveWindowClose()
{
    disconnect(ui, SIGNAL(sendSig()),this,SLOT(receiveWindowClose()));
    sendDataOnClose(cv::Mat(),false,false);
    delete ui;
    ui = 0;
}

QStringList spectralFilteringToolPlugin::toolsIndex() const
{
    return QStringList() << tr("Color Splitter");
}

void spectralFilteringToolPlugin::showUI()
{
    if(!ui)
    {
        ui = new MainWindow;
        if(!ui->isVisible())
        {
            connect(ui, SIGNAL(sendSig()),this,SLOT(receiveWindowClose()));
            ui->show();
        }
    }
}

void spectralFilteringToolPlugin::closeUI()
{
    ui->close();
}

void spectralFilteringToolPlugin::setImage(QImage &img)
{
}

QImage spectralFilteringToolPlugin::returnImage()
{
    return QImage();
}

#ifdef HAVE_OPENCV
void spectralFilteringToolPlugin::setImage(cv::Mat &img)
{
    //_img = img.clone();
    ui->setImageFromMain(img);
}

cv::Mat spectralFilteringToolPlugin::returncvImage()
{
    return cv::Mat();
}
#endif

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2(spectralFiltering, spectralFilteringToolPlugin)
#endif // QT_VERSION < 0x050000
